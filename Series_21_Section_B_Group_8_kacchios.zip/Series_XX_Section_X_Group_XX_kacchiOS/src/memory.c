#include "memory.h"

char heap[HEAP_SIZE];
free_block_t* free_list = NULL;

void init_memory() {
    free_list = (free_block_t*)heap;
    free_list->size = HEAP_SIZE - sizeof(free_block_t);
    free_list->next = NULL;
}

void* kmalloc(size_t size) {
    if (size == 0) return NULL;

    free_block_t* curr = free_list;
    free_block_t* prev = NULL;

    while (curr) {
        if (curr->size >= size) {
            // Allocate
            if (curr->size > size + sizeof(free_block_t)) {
                // Split
                free_block_t* new_free = (free_block_t*)((char*)curr + sizeof(free_block_t) + size);
                new_free->size = curr->size - size - sizeof(free_block_t);
                new_free->next = curr->next;
                curr->size = size;
                if (prev) {
                    prev->next = new_free;
                } else {
                    free_list = new_free;
                }
            } else {
                // Take whole block
                if (prev) {
                    prev->next = curr->next;
                } else {
                    free_list = curr->next;
                }
            }
            return (void*)((char*)curr + sizeof(free_block_t));
        }
        prev = curr;
        curr = curr->next;
    }
    return NULL;  // No suitable block found
}

void kfree(void* ptr) {
    if (!ptr) return;

    free_block_t* block = (free_block_t*)((char*)ptr - sizeof(free_block_t));

    // Insert into free list, sorted by address for merging
    free_block_t* curr = free_list;
    free_block_t* prev = NULL;
    while (curr && (void*)curr < (void*)block) {
        prev = curr;
        curr = curr->next;
    }

    block->next = curr;
    if (prev) {
        prev->next = block;
    } else {
        free_list = block;
    }

    // Merge with next
    if (curr && (char*)block + sizeof(free_block_t) + block->size == (char*)curr) {
        block->size += sizeof(free_block_t) + curr->size;
        block->next = curr->next;
    }

    // Merge with prev
    if (prev && (char*)prev + sizeof(free_block_t) + prev->size == (char*)block) {
        prev->size += sizeof(free_block_t) + block->size;
        prev->next = block->next;
    }
}

void* alloc_stack() {
    const size_t stack_size = 4096;  // 4KB
    const size_t align = 4096;
    size_t extra = sizeof(void*) + align - 1;
    void* orig = kmalloc(stack_size + extra);
    if (!orig) return NULL;

    uintptr_t aligned_addr = ((uintptr_t)orig + sizeof(void*) + align - 1) & ~(align - 1);
    void* aligned = (void*)aligned_addr;
    ((void**)aligned)[-1] = orig;  // Store original pointer before aligned address
    return aligned;
}

void free_stack(void* ptr) {
    if (!ptr) return;
    void* orig = ((void**)ptr)[-1];
    kfree(orig);
}