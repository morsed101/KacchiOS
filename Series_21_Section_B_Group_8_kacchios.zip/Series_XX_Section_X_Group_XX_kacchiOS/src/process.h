#ifndef PROCESS_H
#define PROCESS_H

#include "memory.h"

#define MAX_PROCESSES 10

typedef enum {
    CURRENT,
    READY,
    TERMINATED
} process_state_t;

typedef struct pcb {
    int pid;
    process_state_t state;
    void* stack_ptr;
    void* heap_base;
    void (*entry_point)();
    int age;  // For aging bonus
    // For IPC bonus
    char msg_buffer[256];
    size_t msg_len;
} pcb_t;

extern pcb_t* process_table[MAX_PROCESSES];
extern pcb_t* current_process;
extern int next_pid;

int create_process(void (*entry_point)());
void terminate_process(int pid);
int get_current_pid();
void list_processes();  // For simplicity, assume it prints or something

#endif // PROCESS_H