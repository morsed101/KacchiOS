#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdint.h>

#define TIME_QUANTUM 10  // Configurable quantum

void schedule();
void context_switch(uintptr_t** old_esp, uintptr_t* new_esp);
void timer_interrupt();

#endif // SCHEDULER_H