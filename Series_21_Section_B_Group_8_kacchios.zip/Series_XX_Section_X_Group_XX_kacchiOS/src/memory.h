#ifndef MEMORY_H
#define MEMORY_H

#include <stddef.h>
#include <stdint.h>

#define HEAP_SIZE (1024 * 1024)  // 1MB heap

typedef struct free_block {
    size_t size;
    struct free_block* next;
} free_block_t;

extern char heap[HEAP_SIZE];
extern free_block_t* free_list;

void init_memory();
void* kmalloc(size_t size);
void kfree(void* ptr);
void* alloc_stack();  // Allocates 4KB aligned stack
void free_stack(void* ptr);

#endif // MEMORY_H