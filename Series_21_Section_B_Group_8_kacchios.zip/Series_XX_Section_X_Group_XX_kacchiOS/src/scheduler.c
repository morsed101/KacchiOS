#include "scheduler.h"
#include "process.h"

void schedule() {
    // Find current index
    int current_idx = -1;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (process_table[i] == current_process) {
            current_idx = i;
            break;
        }
    }

    // Set current to READY if running
    if (current_process && current_process->state == CURRENT) {
        current_process->state = READY;
    }

    // Increment age for all READY processes
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (process_table[i] && process_table[i]->state == READY) {
            process_table[i]->age++;
        }
    }

    // Find next READY process, round-robin
    int next_idx = (current_idx + 1) % MAX_PROCESSES;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        int idx = (next_idx + i) % MAX_PROCESSES;
        if (process_table[idx] && process_table[idx]->state == READY) {
            current_process = process_table[idx];
            current_process->state = CURRENT;
            // Context switch would be called here, but need ESP
            // Assume timer_interrupt handles it
            return;
        }
    }
    // No ready process
    current_process = NULL;
}

void context_switch(uintptr_t** old_esp, uintptr_t* new_esp) {
    // x86-64 context switch
    __asm__ volatile (
        "pushq %%rax\n"
        "pushq %%rbx\n"
        "pushq %%rcx\n"
        "pushq %%rdx\n"
        "pushq %%rsi\n"
        "pushq %%rdi\n"
        "pushq %%rbp\n"
        "pushq %%r8\n"
        "pushq %%r9\n"
        "pushq %%r10\n"
        "pushq %%r11\n"
        "pushq %%r12\n"
        "pushq %%r13\n"
        "pushq %%r14\n"
        "pushq %%r15\n"
        "movq %%rsp, (%0)\n"    // Save current RSP to *old_esp
        "movq %1, %%rsp\n"      // Load new RSP from new_esp
        "popq %%r15\n"
        "popq %%r14\n"
        "popq %%r13\n"
        "popq %%r12\n"
        "popq %%r11\n"
        "popq %%r10\n"
        "popq %%r9\n"
        "popq %%r8\n"
        "popq %%rbp\n"
        "popq %%rdi\n"
        "popq %%rsi\n"
        "popq %%rdx\n"
        "popq %%rcx\n"
        "popq %%rbx\n"
        "popq %%rax\n"
        "ret\n"
        : : "r"(old_esp), "r"(new_esp)
    );
}

void timer_interrupt() {
    // Placeholder for timer interrupt
    // Decrement quantum, if 0, schedule
    static int quantum_counter = TIME_QUANTUM;
    quantum_counter--;
    if (quantum_counter <= 0) {
        quantum_counter = TIME_QUANTUM;
        schedule();
        // Then context switch if needed
        // But need to handle ESP, perhaps in interrupt handler
    }
}