#include "memory.h"
#include "process.h"
#include "scheduler.h"
#include <stdio.h>  // For testing, assume available

int main() {
    // Initialize memory
    init_memory();

    // Create some processes
    int pid1 = create_process(NULL);  // Dummy entry point
    printf("Created process %d\n", pid1);

    int pid2 = create_process(NULL);
    printf("Created process %d\n", pid2);

    // Simulate scheduling
    schedule();
    printf("Current PID: %d\n", get_current_pid());

    // Terminate a process
    terminate_process(pid1);
    printf("Terminated process %d\n", pid1);

    // Test memory allocation
    void* ptr = kmalloc(100);
    printf("Allocated memory at %p\n", ptr);
    kfree(ptr);
    printf("Freed memory\n");

    // Test stack allocation
    void* stack = alloc_stack();
    printf("Allocated stack at %p\n", stack);
    free_stack(stack);
    printf("Freed stack\n");

    return 0;
}