#include "process.h"

pcb_t* process_table[MAX_PROCESSES] = {NULL};
pcb_t* current_process = NULL;
int next_pid = 1;

int create_process(void (*entry_point)()) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (process_table[i] == NULL) {
            process_table[i] = (pcb_t*)kmalloc(sizeof(pcb_t));
            if (!process_table[i]) return -1;

            process_table[i]->pid = next_pid++;
            process_table[i]->state = READY;
            process_table[i]->stack_ptr = alloc_stack();
            if (!process_table[i]->stack_ptr) {
                kfree(process_table[i]);
                process_table[i] = NULL;
                return -1;
            }
            process_table[i]->heap_base = NULL;  // Can allocate heap if needed
            process_table[i]->entry_point = entry_point;
            process_table[i]->msg_len = 0;
            process_table[i]->age = 0;
            return process_table[i]->pid;
        }
    }
    return -1;  // No free slot
}

void terminate_process(int pid) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (process_table[i] && process_table[i]->pid == pid) {
            free_stack(process_table[i]->stack_ptr);
            if (process_table[i]->heap_base) {
                kfree(process_table[i]->heap_base);
            }
            kfree(process_table[i]);
            process_table[i] = NULL;
            if (current_process == process_table[i]) {
                current_process = NULL;
            }
            return;
        }
    }
}

int get_current_pid() {
    return current_process ? current_process->pid : -1;
}

void list_processes() {
    // For baremetal, perhaps assume a print function, but for now, just loop
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (process_table[i]) {
            // Assume we have a print function, e.g., printf("PID: %d, State: %d\n", process_table[i]->pid, process_table[i]->state);
        }
    }
}