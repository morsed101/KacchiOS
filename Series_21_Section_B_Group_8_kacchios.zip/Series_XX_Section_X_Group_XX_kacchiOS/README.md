# kacchiOS

A simple baremetal operating system implemented in C, featuring memory management, process management, and scheduling.

## Features

- **Memory Manager**: Free list-based heap allocation with kmalloc/kfree, and 4KB-aligned stack allocation.
- **Process Manager**: PCB-based process creation, termination, and management.
- **Scheduler**: Round-robin scheduling with configurable quantum and aging for fairness.

## Building

Navigate to the `src/` directory and run `make`.

```bash
cd src
make
```

## Running

For testing in user space:

```bash
./kachios
```

For baremetal deployment, integrate with a bootloader and run on hardware or QEMU.

## Project Structure

- `src/`: Source code files
- `docs/`: Documentation (Checklist and Report)
- `video/`: Demo video
- `README.md`: This file

## Authors

[Your Name/Team]